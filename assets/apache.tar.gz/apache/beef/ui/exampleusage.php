<?
	// Copyright (c) 2006-2009, Wade Alcorn 
	// All Rights Reserved
	// wade@bindshell.net - http://www.bindshell.net
?>

<div class="entry">
	<p class="title">Example Usage</p>
	Use a browser to connect to '<a href=../hook/example.php>http://beefserver/beef/hook/example.php</a>' or 
	click the 'Spawn Zombie Example' item in the 'Options' menu. Now a zombie will appear in the zombie 
	section of the BeEF UI. <br><br>

	Select the 'Alert Dialog' module from the 'Standard Modules' menu and then click on the zombie in the 
	sidebar (under the BeEF image). Now both the module and a zombie(s) have been selected. The next step 
	is to click the 'Send Now' button to send the instruction to the zombie.<br><br>

	An alert dialog box should now appear in the zombie. Click the 'OK' button. The results of this
	action will appear in that browser zombie's page. To view these results select the zombie from
	the 'Zombies' pull down menu. This page contains various infomation including 'Module Results'.<br><br>

</div>
