<?
	// Copyright (c) 2006-2009, Wade Alcorn 
	// All Rights Reserved
	// wade@bindshell.net - http://www.bindshell.net
?>

<div class="entry">
	<p class="title">Thanks</p><br>
	Thanks to these people for their feedback and input. It has been very helpful.<br><br>
	- Joshua Abraham<br>
	- Ryan Linn<br>
	- Roberto Suggi Liverani<br>
	- Nick Freeman<br>
	- Pipes<br>
	- Alexios Fakos<br>
	- Achim Hoffman<br>
	- Andres Riancho<br>

</div>

