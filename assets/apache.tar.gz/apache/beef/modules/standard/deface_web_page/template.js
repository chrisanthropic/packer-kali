function do_main(){
	document.body.innerHTML = "HTMLCONTENT";
}

do_main();

return_result(result_id, "Site defaced");