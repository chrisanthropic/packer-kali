
return_result(result_id, clipboardData.getData("Text"));