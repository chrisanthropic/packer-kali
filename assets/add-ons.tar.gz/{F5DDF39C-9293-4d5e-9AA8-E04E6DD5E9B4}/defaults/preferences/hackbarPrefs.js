pref("extensions.{F5DDF39C-9293-4d5e-9AA8-E04E6DD5E9B4}.description", "chrome://hackbar/locale/hackbar.properties");
